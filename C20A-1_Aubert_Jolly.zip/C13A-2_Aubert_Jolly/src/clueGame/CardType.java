package clueGame;

public enum CardType {
	PERSON, ROOM, WEAPON;
}
