package clueGame;

public class BadConfigFormatException extends Exception {

	public BadConfigFormatException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BadConfigFormatException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
