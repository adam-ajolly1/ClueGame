package clueGame;

public class BadConfigFormatException extends Exception {

}
